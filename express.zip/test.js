

<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.10.0/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyBUpES8-DA22Pl7kuE1448s8osMM_HbV7w",
    authDomain: "swimming-399fc.firebaseapp.com",
    projectId: "swimming-399fc",
    storageBucket: "swimming-399fc.appspot.com",
    messagingSenderId: "868892607675",
    appId: "1:868892607675:web:fdb740bd67be8a59e0d59e"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
</script>